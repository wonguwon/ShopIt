package com.kh.shopit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopitApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopitApplication.class, args);
	}

}
